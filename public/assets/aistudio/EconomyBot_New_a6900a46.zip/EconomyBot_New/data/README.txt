이 폴더에는 SQLite 데이터베이스와 브롤러 데이터 캐시가 저장됩니다.
Fly.io에서는 /app/data에 영구 볼륨을 연결해야 데이터가 재시작 후에도 유지됩니다.
brawler_aliases.json에 한국어 별칭을 추가할 수 있습니다.
