import { GameSettings, LeaderboardEntry, PlayerProfile } from '../types';
import { generateRandomName } from './nameGenerator';

const PROFILE_KEY = 'gibanstars_s8_profile_v4';
const SETTINGS_KEY = 'gibanstars_s8_settings_v4';
const LEADERBOARD_KEY = 'gibanstars_s8_leaderboard_v4';
const ACCOUNTS_STORE_KEY = 'gibanstars_s8_accounts_v4';

const ONE_HOUR_MS = 60 * 60 * 1000;
const MAX_FREE_LIVES = 10;

export const INITIAL_SETTINGS: GameSettings = {
  bgmVolume: 0.6,
  sfxVolume: 0.8,
  isMuted: false,
};

export function getTodayDateString(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
}

export function generateSerialNumber(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = new Uint8Array(12);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  const suffix = Array.from(bytes, (value) => alphabet[value % alphabet.length]).join('');
  return `GS8-${suffix}`;
}

export function getInitialProfile(): PlayerProfile {
  return {
    serialNumber: null,
    isLinked: false,
    name: generateRandomName(),
    faction: null,
    highScore: 0,
    totalChips: 0,
    gamesPlayed: 0,
    chipHistory: [],
    // Discord Integration
    discordUserId: null,
    discordUsername: null,
    discordLinked: false,
    discordLinkedAt: null,
    discordSyncedChips: 0,
    discordEventChips: 0,
    pendingGamePurchaseId: null,

    lives: MAX_FREE_LIVES,
    maxFreeLives: MAX_FREE_LIVES,
    lastRechargeTimestamp: Date.now(),
    lastDailyResetDate: getTodayDateString(),
    usedTicketCodes: [],
  };
}

// Synchronize daily reset (10 free plays) and hourly recharge (1 life per hour)
export function syncRechargeLives(profile: PlayerProfile): { profile: PlayerProfile; msUntilNextRecharge: number } {
  let updated = { ...profile };
  const today = getTodayDateString();
  const now = Date.now();

  // 1. Daily Reset Check (10 free plays per day)
  if (updated.lastDailyResetDate !== today) {
    updated.lastDailyResetDate = today;
    if (updated.lives < MAX_FREE_LIVES) {
      updated.lives = MAX_FREE_LIVES;
    }
    updated.lastRechargeTimestamp = now;
  }

  // 2. Hourly Recharge Check (1 life per hour when under max)
  let msUntilNext = ONE_HOUR_MS;

  if (updated.lives < MAX_FREE_LIVES) {
    const elapsed = now - (updated.lastRechargeTimestamp || now);
    const livesToAdd = Math.floor(elapsed / ONE_HOUR_MS);

    if (livesToAdd > 0) {
      updated.lives = Math.min(MAX_FREE_LIVES, updated.lives + livesToAdd);
      updated.lastRechargeTimestamp = now - (elapsed % ONE_HOUR_MS);
      msUntilNext = ONE_HOUR_MS - (elapsed % ONE_HOUR_MS);
    } else {
      msUntilNext = Math.max(0, ONE_HOUR_MS - elapsed);
    }
  } else {
    // Already full or overfilled with tickets
    updated.lastRechargeTimestamp = now;
    msUntilNext = ONE_HOUR_MS;
  }

  // Save if changed
  if (updated.lives !== profile.lives || updated.lastDailyResetDate !== profile.lastDailyResetDate) {
    saveProfile(updated);
  }

  return { profile: updated, msUntilNextRecharge: msUntilNext };
}

export function consumeLife(profile: PlayerProfile): { success: boolean; updatedProfile: PlayerProfile } {
  const { profile: synced } = syncRechargeLives(profile);
  if (synced.lives <= 0) {
    return { success: false, updatedProfile: synced };
  }

  const updated: PlayerProfile = {
    ...synced,
    lives: synced.lives - 1,
    lastRechargeTimestamp: synced.lives === MAX_FREE_LIVES ? Date.now() : synced.lastRechargeTimestamp,
  };

  saveProfile(updated);
  return { success: true, updatedProfile: updated };
}

export function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) {
      const fresh = getInitialProfile();
      saveProfile(fresh);
      return fresh;
    }
    const parsed = JSON.parse(raw);
    // Ensure all new fields exist
    const merged: PlayerProfile = {
      ...getInitialProfile(),
      ...parsed,
      // Legacy client-only Discord links were not verified by the bot server.
      // The real link state is restored from the game API after startup.
      discordLinked: false,
      discordUsername: null,
      discordUserId: null,
      discordEventChips: 0,
    };
    return merged;
  } catch {
    const fresh = getInitialProfile();
    return fresh;
  }
}

export function saveProfile(profile: PlayerProfile) {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));

    if (profile.serialNumber) {
      const allAccounts = loadAllAccounts();
      allAccounts[profile.serialNumber.toUpperCase().trim()] = profile;
      localStorage.setItem(ACCOUNTS_STORE_KEY, JSON.stringify(allAccounts));
    }
  } catch (err) {
    console.error('Failed to save profile', err);
  }
}

export function loadAllAccounts(): Record<string, PlayerProfile> {
  try {
    const raw = localStorage.getItem(ACCOUNTS_STORE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function loadProfileBySerial(serial: string): PlayerProfile | null {
  const cleanSerial = serial.toUpperCase().trim();
  const accounts = loadAllAccounts();
  if (accounts[cleanSerial]) {
    const found = accounts[cleanSerial];
    saveProfile(found);
    return found;
  }
  return null;
}

export function linkNewAccount(currentProfile: PlayerProfile, customName?: string): PlayerProfile {
  const serial = generateSerialNumber();
  const linked: PlayerProfile = {
    ...currentProfile,
    serialNumber: serial,
    isLinked: true,
    name: customName?.trim() || currentProfile.name,
  };
  saveProfile(linked);
  return linked;
}

export function resetAllRecords(): PlayerProfile {
  const fresh = getInitialProfile();
  saveProfile(fresh);
  return fresh;
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return INITIAL_SETTINGS;
    return { ...INITIAL_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return INITIAL_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings) {
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}

const DEFAULT_LEADERBOARD: LeaderboardEntry[] = [
  { id: '1', name: '빛을 품은 문호', faction: 'angel', score: 142, chips: 14 },
  { id: '2', name: '불타오르는 벡스', faction: 'devil', score: 139, chips: 13 },
  { id: '3', name: '천상을 꿈꾸는 세이지', faction: 'angel', score: 118, chips: 11 },
  { id: '4', name: '심연을 딛는 붐', faction: 'devil', score: 115, chips: 11 },
  { id: '5', name: '찬란한 스타릿', faction: 'angel', score: 95, chips: 9 },
  { id: '6', name: '은빛의 링', faction: 'angel', score: 93, chips: 9 },
  { id: '7', name: '지옥불을 다루는 멜라니', faction: 'devil', score: 91, chips: 9 },
  { id: '8', name: '도약하는 플로라', faction: 'angel', score: 84, chips: 8 },
  { id: '9', name: '폭풍의 퀵사', faction: 'devil', score: 79, chips: 7 },
  { id: '10', name: '날렵한 하윤', faction: 'angel', score: 68, chips: 6 },
];

export function loadLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(LEADERBOARD_KEY);
    if (!raw) return DEFAULT_LEADERBOARD;
    return JSON.parse(raw);
  } catch {
    return DEFAULT_LEADERBOARD;
  }
}

export function updateLeaderboard(player: PlayerProfile): LeaderboardEntry[] {
  if (!player.faction || player.highScore <= 0) return loadLeaderboard();

  const current = loadLeaderboard();
  const withoutPlayer = current.filter(e => !e.isPlayer);

  const playerEntry: LeaderboardEntry = {
    id: player.serialNumber || 'player_guest',
    name: player.name,
    faction: player.faction,
    score: player.highScore,
    chips: player.totalChips,
    isPlayer: true,
  };

  const updated = [...withoutPlayer, playerEntry].sort((a, b) => b.score - a.score);
  try {
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(updated.slice(0, 15)));
  } catch (err) {
    console.error(err);
  }
  return updated.slice(0, 15);
}
