import { PlayerProfile } from '../types';

// Set VITE_GAME_API_URL to the public HTTPS URL of the Discord bot's Fly.io app.
const API_BASE = (import.meta.env.VITE_GAME_API_URL || 'https://YOUR-FLY-APP.fly.dev').replace(/\/$/, '');

export interface GameAccountStatus {
  linked: boolean;
  eventChips: number;
  discordUsername?: string;
}

async function post<T>(path: string, body: Record<string, unknown>): Promise<T> {
  if (API_BASE.includes('YOUR-FLY-APP')) {
    throw new Error('게임 API 주소가 아직 설정되지 않았어요. VITE_GAME_API_URL 설정이 필요합니다.');
  }
  const response = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const messages: Record<string, string> = {
      not_linked: '디스코드에서 게임 계정을 먼저 연동해 주세요.',
      coupon_not_found: '쿠폰 번호가 없거나 다른 계정에 발급된 쿠폰이에요.',
      coupon_used: '이미 사용한 쿠폰이에요.',
      insufficient_event_chips: '이벤트 칩이 부족해요. 20개가 필요합니다.',
      request_conflict: '구매 요청이 다른 계정에서 이미 사용되었어요.',
    };
    throw new Error(messages[data.error] || `서버 요청 실패 (${response.status})`);
  }
  return data as T;
}

export async function getGameAccount(serial: string): Promise<GameAccountStatus> {
  return post<GameAccountStatus>('/api/game/account', { serial });
}

export async function redeemGameCoupon(serial: string, code: string): Promise<{ success: boolean; lives: number; code: string; replayed?: boolean }> {
  return post('/api/game/redeem-coupon', { serial, code: code.trim().toUpperCase() });
}

export async function purchaseLifeTicket(serial: string, requestId: string): Promise<{ success: boolean; receiptId: string; lives: number; eventChips: number; replayed?: boolean }> {
  return post('/api/game/purchase-life-ticket', { serial, requestId });
}

export function applyRemoteAccount(profile: PlayerProfile, account: GameAccountStatus): PlayerProfile {
  return {
    ...profile,
    discordLinked: account.linked,
    discordUsername: account.linked ? (account.discordUsername || '디스코드 계정') : null,
    discordEventChips: account.eventChips,
    discordLinkedAt: account.linked ? (profile.discordLinkedAt || new Date().toISOString()) : null,
  };
}

export function createPurchaseRequestId(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `gs8-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}
