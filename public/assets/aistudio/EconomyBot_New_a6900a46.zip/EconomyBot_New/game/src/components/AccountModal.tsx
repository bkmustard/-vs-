import React, { useEffect, useState } from 'react';
import { PlayerProfile } from '../types';
import { linkNewAccount, loadProfileBySerial } from '../utils/storage';
import { applyRemoteAccount, getGameAccount } from '../utils/gameApi';
import { DecorLogo, ChipIcon } from './ThirdImageAsset';

interface AccountModalProps {
  profile: PlayerProfile;
  onUpdateProfile: (newProfile: PlayerProfile) => void;
  onClose: () => void;
}

export const AccountModal: React.FC<AccountModalProps> = ({ profile, onUpdateProfile, onClose }) => {
  const [inputSerial, setInputSerial] = useState('');
  const [customNameInput, setCustomNameInput] = useState(profile.name);
  const [statusMsg, setStatusMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [checking, setChecking] = useState(false);
  const [eventChips, setEventChips] = useState(profile.discordEventChips || 0);
  const [discordUsername, setDiscordUsername] = useState('');
  const [discordLinked, setDiscordLinked] = useState(false);

  const refreshLink = async () => {
    if (!profile.serialNumber) {
      setStatusMsg({ text: '먼저 게임 계정 일련번호를 발급해 주세요.', type: 'error' });
      return;
    }
    setChecking(true);
    try {
      const remote = await getGameAccount(profile.serialNumber);
      const updated = applyRemoteAccount(profile, remote);
      onUpdateProfile(updated);
      setDiscordLinked(remote.linked);
      setDiscordUsername(remote.discordUsername || '');
      setEventChips(remote.eventChips);
      setStatusMsg({
        text: remote.linked ? '디스코드 계정과 동기화했어요.' : '아직 연동되지 않았어요. 아래 명령어를 디스코드 서버에서 입력해 주세요.',
        type: remote.linked ? 'success' : 'error',
      });
    } catch (error) {
      setStatusMsg({ text: error instanceof Error ? error.message : '서버에 연결할 수 없어요.', type: 'error' });
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    if (profile.serialNumber) void refreshLink();
    // Refresh only when the account serial changes or this modal mounts.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile.serialNumber]);

  const handleGenerateSerial = () => {
    const updated = linkNewAccount(profile, customNameInput);
    onUpdateProfile({ ...updated, discordLinked: false, discordUsername: null, discordEventChips: 0 });
    setDiscordLinked(false);
    setEventChips(0);
    setStatusMsg({ text: `게임 계정 일련번호 [${updated.serialNumber}]를 발급했어요. 이 번호를 디스코드 봇에 등록해 주세요.`, type: 'success' });
  };

  const handleLoadAccount = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputSerial.trim()) return;
    const loaded = loadProfileBySerial(inputSerial.trim());
    if (!loaded) {
      setStatusMsg({ text: '이 브라우저에 저장된 해당 일련번호의 계정을 찾지 못했어요.', type: 'error' });
      return;
    }
    onUpdateProfile(loaded);
    setCustomNameInput(loaded.name);
    setDiscordLinked(loaded.discordLinked);
    setDiscordUsername(loaded.discordUsername || '');
    setEventChips(loaded.discordEventChips || 0);
    setStatusMsg({ text: `계정 [${loaded.serialNumber}]을 불러왔어요.`, type: 'success' });
  };

  const handleSaveNickname = () => {
    const trimmed = customNameInput.trim();
    if (!profile.isLinked || !trimmed) return;
    onUpdateProfile({ ...profile, name: trimmed });
    setStatusMsg({ text: '게임 닉네임을 변경했어요.', type: 'success' });
  };

  const handleCopySerial = async () => {
    if (!profile.serialNumber) return;
    try {
      await navigator.clipboard.writeText(profile.serialNumber);
      setStatusMsg({ text: '일련번호를 복사했어요. 디스코드에서 !게임연동 명령어를 사용해 주세요.', type: 'success' });
    } catch {
      setStatusMsg({ text: `일련번호: ${profile.serialNumber}`, type: 'success' });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/80 backdrop-blur-sm animate-fade-in select-none">
      <div className="w-full max-w-md bg-amber-50 rounded-2xl border-4 border-black p-4 md:p-5 shadow-[6px_6px_0px_#000] flex flex-col gap-3.5 max-h-[92vh] overflow-y-auto text-gray-900">
        <div className="flex items-center justify-between border-b-2 border-black pb-2">
          <div className="flex items-center gap-2"><DecorLogo size={26} /><h2 className="text-xl font-black text-black">게임 계정 & 디스코드 연동</h2></div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-red-400 hover:bg-red-500 border-2 border-black font-black text-white flex items-center justify-center shadow-[1px_1px_0px_#000] cursor-pointer text-sm">✕</button>
        </div>

        <div className="bg-gradient-to-r from-indigo-100 via-indigo-50 to-purple-100 rounded-xl border-2 border-black p-3.5 shadow-[3px_3px_0px_#000] flex flex-col gap-2.5">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black flex items-center gap-1.5 text-indigo-950"><span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />디스코드 이벤트 칩 연동</span>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border border-black ${discordLinked ? 'bg-emerald-300 text-emerald-950' : 'bg-amber-200 text-amber-950'}`}>{discordLinked ? '연동 완료' : '미연동'}</span>
          </div>
          {discordLinked ? (
            <div className="bg-white/90 rounded-lg border-2 border-black p-3 flex flex-col gap-2">
              <div className="text-sm font-black text-indigo-950">{discordUsername || '디스코드 계정'}</div>
              <div className="bg-amber-100 rounded-lg border border-black p-2 flex items-center justify-between">
                <div className="flex items-center gap-1.5"><ChipIcon size={18} /><span className="text-xs font-black text-amber-950">이벤트 칩 잔액</span></div>
                <span className="text-base font-black text-amber-900">{eventChips.toLocaleString()}개</span>
              </div>
            </div>
          ) : (
            <p className="text-[11px] text-gray-700 font-bold leading-relaxed">게임에서 일련번호를 발급한 뒤 디스코드 서버에서 아래 명령어를 입력하면 연동됩니다. 닉네임을 입력하는 방식이 아니라 실제 디스코드 계정으로 연결합니다.</p>
          )}
          <button type="button" onClick={() => void refreshLink()} disabled={checking || !profile.serialNumber} className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg border-2 border-black font-black text-xs shadow-[1px_1px_0px_#000] cursor-pointer">{checking ? '확인 중…' : '디스코드 연동 상태 / 잔액 새로고침'}</button>
        </div>

        <div className="bg-white rounded-xl border-2 border-black p-3.5 flex flex-col gap-2.5 shadow-[2px_2px_0px_#000]">
          <div className="flex items-center justify-between"><span className="text-xs font-black text-black">게임 계정 고유 일련번호</span>{profile.isLinked && <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded border border-black">저장됨</span>}</div>
          {profile.isLinked && profile.serialNumber ? (
            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between bg-amber-50 rounded-lg border border-black p-2">
                <div><span className="text-[10px] font-bold text-gray-500 uppercase">일련번호</span><div className="font-mono font-black text-sm text-emerald-900 tracking-wider">{profile.serialNumber}</div></div>
                <button onClick={() => void handleCopySerial()} className="px-2.5 py-1 bg-emerald-300 hover:bg-emerald-400 rounded border border-black font-black text-xs shadow-[1px_1px_0px_#000] cursor-pointer">복사</button>
              </div>
              <div className="bg-indigo-50 border border-indigo-300 rounded-lg p-2 text-[11px] font-bold text-indigo-950 leading-relaxed">디스코드 서버에서 다음 명령어를 입력하세요.<br /><code className="font-mono">!게임연동 {profile.serialNumber}</code></div>
              <div className="flex flex-col gap-1"><label className="text-[11px] font-bold text-gray-700">게임 닉네임 변경</label><div className="flex gap-2"><input type="text" value={customNameInput} onChange={(e) => setCustomNameInput(e.target.value)} maxLength={16} className="flex-1 px-3 py-1 bg-gray-50 rounded-lg border-2 border-black font-bold text-xs" /><button onClick={handleSaveNickname} className="px-3 py-1 bg-yellow-400 hover:bg-yellow-300 rounded-lg border-2 border-black font-black text-xs shadow-[1px_1px_0px_#000] cursor-pointer">변경</button></div></div>
            </div>
          ) : (
            <div className="flex flex-col gap-2"><p className="text-[11px] text-gray-600 font-bold leading-relaxed">일련번호를 발급하면 이 게임 계정을 디스코드 계정에 연결할 수 있어요.</p><button onClick={handleGenerateSerial} className="w-full py-2 bg-emerald-400 hover:bg-emerald-300 rounded-lg border-2 border-black font-black text-xs shadow-[1px_1px_0px_#000] cursor-pointer">새 게임 계정 일련번호 발급</button></div>
          )}
        </div>

        <div className="bg-amber-100/60 rounded-xl border-2 border-black p-3 flex flex-col gap-1.5 shadow-[2px_2px_0px_#000]"><span className="text-xs font-black text-black">이 브라우저의 기존 계정 불러오기</span><form onSubmit={handleLoadAccount} className="flex gap-2"><input type="text" placeholder="예: GS8-일련번호" value={inputSerial} onChange={(e) => setInputSerial(e.target.value)} className="flex-1 px-3 py-1.5 bg-white rounded-lg border-2 border-black font-mono font-bold text-xs" /><button type="submit" className="px-3.5 py-1.5 bg-yellow-400 hover:bg-yellow-300 rounded-lg border-2 border-black font-black text-xs shadow-[1px_1px_0px_#000] cursor-pointer whitespace-nowrap">불러오기</button></form></div>

        {statusMsg && <div className={`text-xs font-black p-2.5 rounded-lg border-2 border-black ${statusMsg.type === 'success' ? 'bg-emerald-100 text-emerald-900' : 'bg-rose-100 text-rose-900'}`}>{statusMsg.text}</div>}
        <button onClick={onClose} className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 rounded-xl border-2 border-black font-black text-sm shadow-[2px_2px_0px_#000] cursor-pointer">확인</button>
      </div>
    </div>
  );
};
